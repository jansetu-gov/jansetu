// ── JanSetu Gov Design Tokens ──────────────────────────────
export const COLORS = {
  primary: "#FF6B35",       // Deep Saffron
  navy: "#0A192F",          // Deep Navy
  brickRed: "#D32F2F",      // Anomaly / destructive
  success: "#2E7D32",       // Green for good utilization
  warning: "#F57F17",       // Amber for medium anomalies
  background: "#FFFFFF",
  cardBg: "#F8F9FA",
  border: "#E0E4EA",
  muted: "#6B7280",
  textDark: "#0A192F",
};

export const DEMO_BADGE = "Demo Mode — Synthetic Data";
export const DEMO_DATASET_LABEL = "Demo Dataset — Verify with Official Source";

// ── Languages ─────────────────────────────────────────────
export type LangCode = "en" | "hi" | "as" | "bn";

export const LANGUAGES: { code: LangCode; label: string; nativeLabel: string }[] = [
  { code: "en", label: "English", nativeLabel: "English" },
  { code: "hi", label: "Hindi", nativeLabel: "हिंदी" },
  { code: "as", label: "Assamese", nativeLabel: "অসমীয়া" },
  { code: "bn", label: "Bengali", nativeLabel: "বাংলা" },
];

// ── Indian Number Formatting ───────────────────────────────
export function formatINR(crore: number): string {
  if (crore >= 100) return `₹${(crore / 100).toFixed(1)} Hundred Cr`;
  if (crore >= 1) return `₹${crore.toFixed(2)} Cr`;
  const lakh = crore * 100;
  if (lakh >= 1) return `₹${lakh.toFixed(1)} L`;
  return `₹${(crore * 10000000).toLocaleString("en-IN")}`;
}

export function formatBeneficiaries(n: number): string {
  if (n >= 100000) return `${(n / 100000).toFixed(1)}L`;
  if (n >= 1000) return `${(n / 1000).toFixed(1)}K`;
  return String(n);
}

// ── States & Districts ─────────────────────────────────────
export const STATES_DISTRICTS: Record<string, string[]> = {
  Assam: ["Kamrup", "Jorhat", "Dibrugarh", "Guwahati", "Nagaon"],
  Bihar: ["Patna", "Gaya", "Muzaffarpur", "Bhagalpur", "Darbhanga"],
  Jharkhand: ["Ranchi", "Dhanbad", "Jamshedpur", "Bokaro", "Hazaribagh"],
  "West Bengal": ["Kolkata", "Howrah", "Durgapur", "Asansol", "Siliguri"],
  "Uttar Pradesh": ["Lucknow", "Varanasi", "Agra", "Kanpur", "Allahabad"],
  Maharashtra: ["Pune", "Mumbai", "Nagpur", "Nashik", "Aurangabad"],
};

export const FINANCIAL_YEARS = ["2024-25", "2023-24", "2022-23"];

// ── Scheme Categories ──────────────────────────────────────
export const SCHEME_CATEGORIES = [
  "Agriculture",
  "Education",
  "Women & Child",
  "Health",
  "Housing",
  "Employment",
  "MSME",
  "Senior Citizens",
  "Scholarships",
  "Rural Development",
];

export const CATEGORY_ICONS: Record<string, string> = {
  Agriculture: "🌾",
  Education: "🎓",
  "Women & Child": "👩‍👧",
  Health: "🏥",
  Housing: "🏠",
  Employment: "💼",
  MSME: "🏭",
  "Senior Citizens": "👴",
  Scholarships: "📚",
  "Rural Development": "🌱",
};

// ── Lifecycle steps ────────────────────────────────────────
export const LIFECYCLE_STEPS = [
  "Discover",
  "Check Eligibility",
  "Apply",
  "Govt Funding",
  "Implementation",
  "Public Transparency",
];

// ── Translations ───────────────────────────────────────────
export const T: Record<LangCode, Record<string, string>> = {
  en: {
    appName: "JanSetu Gov",
    tagline: "From Scheme Discovery to Government Accountability",
    findMySchemes: "Find My Schemes",
    govDashboard: "Government Dashboard",
    publicView: "Public Transparency",
    speakToSearch: "Speak to Search",
    orTypeHere: "Or type your query here...",
    listening: "Listening...",
    searchSchemes: "Search schemes...",
    mySchemes: "My Schemes",
    profile: "Profile",
    home: "Home",
    search: "Search",
    eligibility: "Eligibility",
    benefits: "Benefits",
    documents: "Documents",
    applyNow: "Apply Now",
    checkEligibility: "Check My Eligibility",
    bookmark: "Bookmark",
    bookmarked: "Bookmarked",
    demoMode: "Demo Mode",
    voicePromptHint: 'Try: "I am a farmer with 2 acres, need financial help"',
    language: "Language",
    logout: "Logout",
    saveScheme: "Save Scheme",
    applicationStatus: "Application Status",
    submitted: "Submitted",
    under_review: "Under Review",
    approved: "Approved",
    disbursed: "Disbursed",
    selectRole: "Select Your Role",
    citizen: "Citizen",
    officer: "Government Officer",
    publicViewer: "Public Viewer",
  },
  hi: {
    appName: "जनसेतु गव",
    tagline: "योजना खोज से सरकारी जवाबदेही तक",
    findMySchemes: "मेरी योजनाएं खोजें",
    govDashboard: "सरकारी डैशबोर्ड",
    publicView: "सार्वजनिक पारदर्शिता",
    speakToSearch: "खोजने के लिए बोलें",
    orTypeHere: "या यहाँ टाइप करें...",
    listening: "सुन रहा है...",
    searchSchemes: "योजनाएं खोजें...",
    mySchemes: "मेरी योजनाएं",
    profile: "प्रोफाइल",
    home: "होम",
    search: "खोज",
    eligibility: "पात्रता",
    benefits: "लाभ",
    documents: "दस्तावेज़",
    applyNow: "अभी आवेदन करें",
    checkEligibility: "पात्रता जांचें",
    bookmark: "सहेजें",
    bookmarked: "सहेजा गया",
    demoMode: "डेमो मोड",
    voicePromptHint: 'कहें: "मेरे पास 2 एकड़ जमीन है, खेती के लिए मदद चाहिए"',
    language: "भाषा",
    logout: "लॉग आउट",
    saveScheme: "योजना सहेजें",
    applicationStatus: "आवेदन स्थिति",
    submitted: "जमा किया",
    under_review: "समीक्षाधीन",
    approved: "स्वीकृत",
    disbursed: "वितरित",
    selectRole: "अपनी भूमिका चुनें",
    citizen: "नागरिक",
    officer: "सरकारी अधिकारी",
    publicViewer: "सार्वजनिक दर्शक",
  },
  as: {
    appName: "জনসেতু গভ",
    tagline: "আঁচনি আৱিষ্কাৰৰ পৰা চৰকাৰী দায়বদ্ধতালৈ",
    findMySchemes: "মোৰ আঁচনি বিচাৰক",
    govDashboard: "চৰকাৰী ড্যাশবোর্ড",
    publicView: "ৰাজহুৱা স্বচ্ছতা",
    speakToSearch: "সন্ধানৰ বাবে কথা কওক",
    orTypeHere: "বা ইয়াত টাইপ কৰক...",
    listening: "শুনিছে...",
    searchSchemes: "আঁচনি বিচাৰক...",
    mySchemes: "মোৰ আঁচনিসমূহ",
    profile: "প্ৰ'ফাইল",
    home: "হোম",
    search: "সন্ধান",
    eligibility: "যোগ্যতা",
    benefits: "সুবিধা",
    documents: "নথিপত্ৰ",
    applyNow: "এতিয়া আবেদন কৰক",
    checkEligibility: "যোগ্যতা পৰীক্ষা কৰক",
    bookmark: "সংৰক্ষণ",
    bookmarked: "সংৰক্ষিত",
    demoMode: "ডেমো মোড",
    voicePromptHint: 'কওক: "মোৰ 2 বিঘা মাটি আছে, খেতিৰ বাবে সহায় লাগে"',
    language: "ভাষা",
    logout: "লগ আউট",
    saveScheme: "আঁচনি সংৰক্ষণ",
    applicationStatus: "আবেদনৰ অৱস্থা",
    submitted: "দাখিল কৰা হৈছে",
    under_review: "পৰ্যালোচনাধীন",
    approved: "অনুমোদিত",
    disbursed: "বিতৰণ কৰা হৈছে",
    selectRole: "আপোনাৰ ভূমিকা বাছক",
    citizen: "নাগৰিক",
    officer: "চৰকাৰী বিষয়া",
    publicViewer: "ৰাজহুৱা দৰ্শক",
  },
  bn: {
    appName: "জনসেতু গভ",
    tagline: "প্রকল্প আবিষ্কার থেকে সরকারি জবাবদিহিতা",
    findMySchemes: "আমার প্রকল্প খুঁজুন",
    govDashboard: "সরকারি ড্যাশবোর্ড",
    publicView: "সার্বজনীন স্বচ্ছতা",
    speakToSearch: "অনুসন্ধানের জন্য বলুন",
    orTypeHere: "বা এখানে টাইপ করুন...",
    listening: "শুনছে...",
    searchSchemes: "প্রকল্প খুঁজুন...",
    mySchemes: "আমার প্রকল্প",
    profile: "প্রোফাইল",
    home: "হোম",
    search: "অনুসন্ধান",
    eligibility: "যোগ্যতা",
    benefits: "সুবিধা",
    documents: "নথিপত্র",
    applyNow: "এখনই আবেদন করুন",
    checkEligibility: "যোগ্যতা যাচাই করুন",
    bookmark: "সংরক্ষণ",
    bookmarked: "সংরক্ষিত",
    demoMode: "ডেমো মোড",
    voicePromptHint: 'বলুন: "আমার ২ বিঘা জমি আছে, কৃষির জন্য সাহায্য দরকার"',
    language: "ভাষা",
    logout: "লগ আউট",
    saveScheme: "প্রকল্প সংরক্ষণ",
    applicationStatus: "আবেদনের অবস্থা",
    submitted: "জমা দেওয়া হয়েছে",
    under_review: "পর্যালোচনাধীন",
    approved: "অনুমোদিত",
    disbursed: "বিতরণ করা হয়েছে",
    selectRole: "আপনার ভূমিকা বেছে নিন",
    citizen: "নাগরিক",
    officer: "সরকারি কর্মকর্তা",
    publicViewer: "সার্বজনীন দর্শক",
  },
};
