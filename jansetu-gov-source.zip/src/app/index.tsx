import { useRouter } from "expo-router";
import { ScrollView, Text, View, Pressable } from "react-native";
import { StatusBar } from "expo-status-bar";
import { useApp } from "@/lib/appContext";
import { COLORS, LIFECYCLE_STEPS, T } from "@/lib/constants";

const ROLES = [
  {
    key: "citizen" as const,
    emoji: "🙋",
    color: COLORS.primary,
    route: "/(auth)/sign-in?role=citizen",
  },
  {
    key: "officer" as const,
    emoji: "🏛️",
    color: COLORS.navy,
    route: "/(auth)/sign-in?role=officer",
  },
  {
    key: "public" as const,
    emoji: "👁️",
    color: "#2E7D32",
    route: "/(public)/transparency",
  },
];

export default function LandingScreen() {
  const router = useRouter();
  const { lang, setSelectedRole } = useApp();
  const t = T[lang];

  function handleRole(role: (typeof ROLES)[number]) {
    setSelectedRole(role.key);
    router.push(role.route as never);
  }

  return (
    <ScrollView
      className="flex-1 bg-background"
      contentContainerClassName="pb-12"
      contentInsetAdjustmentBehavior="automatic"
    >
      <StatusBar style="dark" backgroundColor="#ffffff" />

      {/* Header */}
      <View className="bg-secondary pt-14 pb-8 px-6 items-center">
        <Text className="text-4xl font-bold text-white text-center">{t.appName}</Text>
        <View
          className="w-12 h-1 mt-2 mb-3 rounded-full"
          style={{ backgroundColor: COLORS.primary }}
        />
        <Text className="text-base text-white/80 text-center">{t.tagline}</Text>
        {/* Demo badge */}
        <View
          className="mt-4 px-3 py-1 rounded-sm"
          style={{ backgroundColor: "rgba(255,107,53,0.25)" }}
        >
          <Text className="text-xs font-semibold" style={{ color: COLORS.primary }}>
            ● Demo Mode — Synthetic Data
          </Text>
        </View>
      </View>

      {/* Role Selection */}
      <View className="px-6 mt-8">
        <Text className="text-xl font-bold text-foreground mb-1">{t.selectRole}</Text>
        <Text className="text-sm text-muted-foreground mb-5">
          Choose how you want to use JanSetu Gov
        </Text>

        {ROLES.map((role) => (
          <Pressable
            key={role.key}
            className="mb-4 rounded-sm border border-border bg-card active:opacity-80"
            onPress={() => handleRole(role)}
            android_ripple={{ color: "rgba(0,0,0,0.06)" }}
          >
            <View className="p-5 flex-row items-center gap-4">
              <View
                className="w-14 h-14 rounded-sm items-center justify-center"
                style={{ backgroundColor: `${role.color}18` }}
              >
                <Text className="text-3xl">{role.emoji}</Text>
              </View>
              <View className="flex-1">
                <Text className="text-lg font-bold text-foreground">
                  {t[role.key as keyof typeof t]}
                </Text>
                <Text className="text-sm text-muted-foreground mt-0.5">
                  {role.key === "citizen" && "Discover schemes, check eligibility, apply"}
                  {role.key === "officer" && "Track funds, monitor utilization, review anomalies"}
                  {role.key === "public" && "View fund utilization & accountability data"}
                </Text>
              </View>
              <Text className="text-xl" style={{ color: role.color }}>›</Text>
            </View>
          </Pressable>
        ))}
      </View>

      {/* Lifecycle Strip */}
      <View className="mx-6 mt-6 bg-card border border-border rounded-sm p-4">
        <Text className="text-xs font-semibold text-muted-foreground mb-3 uppercase tracking-wider">
          Government Scheme Lifecycle
        </Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <View className="flex-row items-center gap-1">
            {LIFECYCLE_STEPS.map((step, i) => (
              <View key={step} className="flex-row items-center">
                <View
                  className="px-2 py-1 rounded-sm"
                  style={{ backgroundColor: i === 0 ? `${COLORS.primary}18` : "#f1f5f9" }}
                >
                  <Text
                    className="text-xs font-semibold"
                    style={{ color: i === 0 ? COLORS.primary : COLORS.navy }}
                  >
                    {step}
                  </Text>
                </View>
                {i < LIFECYCLE_STEPS.length - 1 && (
                  <Text className="text-muted-foreground text-xs mx-0.5">→</Text>
                )}
              </View>
            ))}
          </View>
        </ScrollView>
      </View>

      {/* Footer note */}
      <Text className="text-center text-xs text-muted-foreground mt-8 px-6">
        JanSetu Gov — Hackathon MVP Demo{"\n"}All data is synthetic. Not affiliated with Government of India.
      </Text>
    </ScrollView>
  );
}
