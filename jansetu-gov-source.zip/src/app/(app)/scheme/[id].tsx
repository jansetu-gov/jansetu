import { useCallback, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  Text,
  View,
  Linking,
} from "react-native";
import { useLocalSearchParams, useRouter, useFocusEffect } from "expo-router";
import { ArrowLeft, Bookmark, CheckCircle, FileText, ExternalLink, MapPin, ChevronRight } from "lucide-react-native";
import { useApp } from "@/lib/appContext";
import { useSession } from "@/ctx";
import { CATEGORY_ICONS, COLORS, DEMO_DATASET_LABEL, T } from "@/lib/constants";
import { fetchSchemeById, isBookmarked, toggleBookmark, createApplication } from "@/db/api";

export default function SchemeDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { lang } = useApp();
  const { session } = useSession();
  const t = T[lang];

  type SchemeRow = {
    name: string;
    department: string;
    category: string;
    description: string;
    state_availability: string[];
    eligibility_income_limit: number | null;
    eligibility_age_min: number | null;
    eligibility_age_max: number | null;
    eligibility_occupation: string[] | null;
    benefits: string;
    required_documents: string[];
    application_process: string[];
    application_url: string | null;
    csc_info: string | null;
    last_updated: string | null;
    [key: string]: unknown;
  };
  const [scheme, setScheme] = useState<SchemeRow | null>(null);
  const [loading, setLoading] = useState(true);
  const [bookmarked, setBookmarked] = useState(false);
  const [applying, setApplying] = useState(false);
  const [applied, setApplied] = useState(false);

  useFocusEffect(
    useCallback(() => {
      if (!id) return;
      setLoading(true);
      Promise.all([
        fetchSchemeById(id),
        session?.user.id ? isBookmarked(session.user.id, id) : Promise.resolve(false),
      ])
        .then(([s, bm]) => { setScheme(s); setBookmarked(bm); })
        .finally(() => setLoading(false));
    }, [id, session?.user.id])
  );

  async function handleBookmark() {
    if (!session?.user.id || !id) return;
    const nowBm = await toggleBookmark(session.user.id, id);
    setBookmarked(nowBm);
  }

  async function handleApply() {
    if (!session?.user.id || !scheme) return;
    setApplying(true);
    try {
      await createApplication(session.user.id, id, scheme.name);
      setApplied(true);
    } finally {
      setApplying(false);
    }
  }

  if (loading) {
    return (
      <View className="flex-1 items-center justify-center bg-background">
        <ActivityIndicator color={COLORS.primary} size="large" />
      </View>
    );
  }

  if (!scheme) {
    return (
      <View className="flex-1 items-center justify-center bg-background px-6">
        <Text className="text-base font-semibold text-foreground">Scheme not found</Text>
        <Pressable onPress={() => router.back()} className="mt-4">
          <Text style={{ color: COLORS.primary }}>← Go Back</Text>
        </Pressable>
      </View>
    );
  }

  const docs = scheme.required_documents;
  const steps = scheme.application_process;

  return (
    <View className="flex-1 bg-background">
      {/* Header bar */}
      <View className="px-4 pt-14 pb-4 bg-card border-b border-border flex-row items-center gap-3">
        <Pressable onPress={() => router.back()} hitSlop={8}>
          <ArrowLeft size={22} color={COLORS.navy} />
        </Pressable>
        <Text className="flex-1 text-base font-bold text-foreground" numberOfLines={1}>
          {scheme.name}
        </Text>
        <Pressable onPress={handleBookmark} hitSlop={8}>
          <Bookmark
            size={22}
            color={bookmarked ? COLORS.primary : COLORS.muted}
            fill={bookmarked ? COLORS.primary : "transparent"}
          />
        </Pressable>
      </View>

      <ScrollView contentInsetAdjustmentBehavior="automatic" className="flex-1">
        {/* Hero */}
        <View className="px-5 py-5" style={{ backgroundColor: COLORS.navy }}>
          <View className="flex-row items-center gap-2 mb-2">
            <Text className="text-2xl">{CATEGORY_ICONS[scheme.category] ?? "📋"}</Text>
            <View className="bg-white/20 px-2 py-0.5 rounded-sm">
              <Text className="text-xs text-white font-semibold">{scheme.category}</Text>
            </View>
          </View>
          <Text className="text-xl font-bold text-white mb-1">{scheme.name}</Text>
          <Text className="text-sm text-white/70">{scheme.department}</Text>
          <Text className="text-sm text-white/80 mt-3">{scheme.description}</Text>
          {/* Demo label */}
          <View className="mt-3 px-2 py-1 rounded-sm self-start" style={{ backgroundColor: "rgba(255,107,53,0.2)" }}>
            <Text className="text-xs font-semibold" style={{ color: COLORS.primary }}>{DEMO_DATASET_LABEL}</Text>
          </View>
        </View>

        {/* Eligibility */}
        <SectionCard title={t.eligibility} icon="✅">
          {scheme.eligibility_income_limit && (
            <InfoRow label="Income Limit" value={`Up to ₹${(scheme.eligibility_income_limit / 100000).toFixed(1)} Lakh per year`} />
          )}
          {scheme.eligibility_age_min && (
            <InfoRow
              label="Age"
              value={`${scheme.eligibility_age_min}${scheme.eligibility_age_max ? ` – ${scheme.eligibility_age_max}` : "+"} years`}
            />
          )}
          {scheme.eligibility_occupation?.length && (
            <InfoRow label="Occupation" value={scheme.eligibility_occupation.join(", ")} />
          )}
          <InfoRow label="State Availability" value={scheme.state_availability.join(", ")} />
          <Pressable
            onPress={() => router.push("/(app)/eligibility")}
            className="mt-3 flex-row items-center gap-1"
          >
            <CheckCircle size={14} color={COLORS.primary} />
            <Text className="text-sm font-semibold" style={{ color: COLORS.primary }}>
              {t.checkEligibility}
            </Text>
          </Pressable>
        </SectionCard>

        {/* Benefits */}
        <SectionCard title={t.benefits} icon="💰">
          <Text className="text-sm text-foreground leading-5">{scheme.benefits}</Text>
        </SectionCard>

        {/* Documents */}
        <SectionCard title={t.documents} icon="📄">
          {docs.map((doc, i) => (
            <View key={i} className="flex-row items-start gap-2 mb-1.5">
              <FileText size={14} color={COLORS.primary} />
              <Text className="text-sm text-foreground flex-1">{doc}</Text>
            </View>
          ))}
        </SectionCard>

        {/* Application Process */}
        <SectionCard title="Application Process" icon="📝">
          {steps.map((step, i) => (
            <View key={i} className="flex-row items-start gap-3 mb-3">
              <View
                className="w-6 h-6 rounded-full items-center justify-center mt-0.5"
                style={{ backgroundColor: COLORS.primary }}
              >
                <Text className="text-white text-xs font-bold">{i + 1}</Text>
              </View>
              <Text className="text-sm text-foreground flex-1 leading-5">{step}</Text>
            </View>
          ))}
          {scheme.application_url && (
            <Pressable
              className="flex-row items-center gap-2 mt-2 p-3 rounded-sm border"
              style={{ borderColor: COLORS.primary }}
              onPress={() => Linking.openURL(scheme.application_url!)}
            >
              <ExternalLink size={16} color={COLORS.primary} />
              <Text className="text-sm font-semibold flex-1" style={{ color: COLORS.primary }}>
                Official Portal: {scheme.application_url}
              </Text>
            </Pressable>
          )}
        </SectionCard>

        {/* CSC Info */}
        {scheme.csc_info && (
          <SectionCard title="Help / CSC Centre" icon="📍">
            <View className="flex-row items-start gap-2">
              <MapPin size={16} color={COLORS.navy} />
              <Text className="text-sm text-foreground flex-1">{scheme.csc_info}</Text>
            </View>
          </SectionCard>
        )}

        {/* Apply / Track */}
        <View className="px-5 pb-10 gap-3 mt-2">
          {applied ? (
            <View className="rounded-sm py-4 items-center" style={{ backgroundColor: "#e8f5e9" }}>
              <View className="flex-row items-center gap-2">
                <CheckCircle size={18} color="#2E7D32" />
                <Text className="font-bold" style={{ color: "#2E7D32" }}>
                  Demo application submitted! Check My Schemes.
                </Text>
              </View>
            </View>
          ) : (
            <Pressable
              className="rounded-sm py-4 items-center active:opacity-80"
              style={{ backgroundColor: COLORS.primary }}
              onPress={handleApply}
              disabled={applying}
            >
              {applying ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text className="text-white font-bold text-base">{t.applyNow} (Demo)</Text>
              )}
            </Pressable>
          )}
          <Pressable
            className="rounded-sm py-4 items-center border"
            style={{ borderColor: COLORS.navy }}
            onPress={() => router.push("/(app)/(citizen)/my-schemes")}
          >
            <Text className="font-bold text-base" style={{ color: COLORS.navy }}>Track My Application →</Text>
          </Pressable>
        </View>
      </ScrollView>
    </View>
  );
}

function SectionCard({
  title, icon, children,
}: { title: string; icon: string; children: React.ReactNode }) {
  return (
    <View className="mx-4 mt-3 bg-card border border-border rounded-sm p-4">
      <View className="flex-row items-center gap-2 mb-3 pb-2 border-b border-border">
        <Text className="text-base">{icon}</Text>
        <Text className="text-base font-bold text-foreground">{title}</Text>
      </View>
      {children}
    </View>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <View className="flex-row items-start gap-2 mb-2">
      <Text className="text-sm text-muted-foreground w-28">{label}:</Text>
      <Text className="text-sm font-semibold text-foreground flex-1">{value}</Text>
    </View>
  );
}
